package cpsc411.miniapp4.ui.main

import android.arch.lifecycle.ViewModel
import android.databinding.*


class MainViewModel : ViewModel(){

    val transferTime = ObservableField<String>()
    var nSpeed = ""
    var fSize = ""


    fun calculate(){
        if (nSpeed.isBlank()){
            nSpeed = "0.0"
        }
        if (fSize.isBlank()){
            fSize = "0.0"
        }

        val result = String.format("%1$.1f seconds",(fSize.toDouble()* 1024.0 * 8.0)/((nSpeed.toDouble()*1000)))
        transferTime.set(result)
    }

}

